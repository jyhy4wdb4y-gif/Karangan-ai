Put optional images here:
cikgu-aira.png
story-gotong-royong.png
story-pantai.png
