const SYSTEM = `You are Cikgu Aira, a safe Bahasa Melayu writing coach for Malaysian Year 3 primary pupils.
You coach, not ghostwrite. Never produce a full ready-to-submit essay.
Keep target Bahasa Melayu content in BM. Use concise Simplified Chinese only for explanations when useful.
Return valid JSON only:
{
  "score": 0,
  "feedback": {
    "pujian": "",
    "baik": [],
    "baiki": [],
    "soalan": ""
  }
}
Use child-friendly language and specific, actionable guidance.`;

function extractText(data){
  if(typeof data?.output_text==="string") return data.output_text;
  const out=[];
  for(const item of data?.output||[]) for(const c of item?.content||[]) if(typeof c?.text==="string") out.push(c.text);
  return out.join("\n");
}

export default async function handler(req,res){
  if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
  const {text="",prompt="",year=3,mentorLanguage="zh"}=req.body||{};
  if(typeof text!=="string" || text.trim().length<8) return res.status(400).json({error:"Writing too short"});
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:"AI not configured"});
  try{
    const r=await fetch("https://api.openai.com/v1/responses",{
      method:"POST",
      headers:{"Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        model:process.env.OPENAI_MODEL || "gpt-5.4-mini",
        input:[
          {role:"system",content:SYSTEM},
          {role:"user",content:`Year: ${year}\nMentor language: ${mentorLanguage}\nTask: ${prompt}\nPupil writing:\n${text}`}
        ]
      })
    });
    if(!r.ok) return res.status(502).json({error:"AI service unavailable"});
    const data=await r.json();
    const raw=extractText(data).replace(/^```json\s*/i,"").replace(/```$/,"").trim();
    const parsed=JSON.parse(raw);
    return res.status(200).json({
      source:"ai",
      score:Math.max(0,Math.min(100,Number(parsed.score)||0)),
      feedback:{
        pujian:String(parsed.feedback?.pujian||"Bagus kerana kamu sudah mencuba."),
        baik:Array.isArray(parsed.feedback?.baik)?parsed.feedback.baik.slice(0,2).map(String):[],
        baiki:Array.isArray(parsed.feedback?.baiki)?parsed.feedback.baiki.slice(0,2).map(String):["Semak semula ayat kamu."],
        soalan:String(parsed.feedback?.soalan||"Apa lagi yang boleh kamu tambah?")
      }
    });
  }catch(e){return res.status(502).json({error:"AI service unavailable"});}
}
