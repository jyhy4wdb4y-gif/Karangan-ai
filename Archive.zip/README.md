# Karangan AI — Full Developer Build v1

This is a modular Vercel web build aligned to the Master PRD v2.0 baseline.

## Included modules
- App Shell
- Today's Mission
- Story Library
- Story Reader
- Tap-any-word Chinese translation
- BM text-to-speech
- Grammar highlighting
- Vocabulary Book
- Sentence Builder
- Grammar Rain
- Sentence Recall
- Creative Studio
- AI Feedback with local fallback
- XP, Reward, Levels, Profile
- Local persistence
- Local event logging
- Responsive iPad/iPhone layout
- Vercel serverless AI endpoint

## Existing images
The app checks these first:
- cikgu-aira.png
- story-gotong-royong.png
- 2411F84C-22BF-4BE2-848E-BE95A12D02A9.png

It also checks assets/images equivalents.

## Vercel setup
Add environment variable:
- OPENAI_API_KEY
Optional:
- OPENAI_MODEL

Never put the API key in browser JavaScript.

## Important
This is a formal modular web implementation for the P0/P1 learning loop.
P2/P3 account/cloud/school systems are intentionally not enabled in this build.
