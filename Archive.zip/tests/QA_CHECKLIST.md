# QA Checklist

- [ ] Home renders on iPhone and iPad
- [ ] Story image fallback works
- [ ] Cikgu Aira image fallback works
- [ ] Tap a BM word shows translation
- [ ] Save Word persists after reload
- [ ] BM speech button works
- [ ] Grammar highlight toggles work
- [ ] Sentence Builder validates order
- [ ] Grammar Rain advances
- [ ] Sentence Recall validates answer
- [ ] Writing persists locally
- [ ] AI feedback returns or falls back locally
- [ ] XP does not duplicate unexpectedly on normal flow
- [ ] Reward page appears
- [ ] Profile level updates
- [ ] Reset progress works
- [ ] No hard crash when offline
