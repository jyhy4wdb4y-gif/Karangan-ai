window.KAI_STATE = {
  defaultState: {
    route:"home",
    currentStoryId:null,
    storyStep:"read",
    xp:0,
    savedWords:[],
    completed:{},
    badges:[],
    writing:"",
    feedback:null,
    mentorOpen:true,
    selectedWord:null,
    grammarMode:{verbs:false,adjectives:false,numbers:false},
    quiz:{index:0,score:0,locked:false},
    builder:[],
    grammar:{index:0,score:0}
  },
  state:null,
  init(){
    this.state = window.StorageService.load() || JSON.parse(JSON.stringify(this.defaultState));
  },
  set(patch, render=true){
    this.state = {...this.state,...patch};
    window.StorageService.save(this.state);
    if(render && window.Router) window.Router.render();
  },
  mutate(fn, render=true){
    fn(this.state);
    window.StorageService.save(this.state);
    if(render && window.Router) window.Router.render();
  }
};
