window.KAI_CONFIG = {
  appName: "Karangan AI",
  targetYear: 3,
  mentorName: "Cikgu Aira",
  mentorLanguage: "zh",
  targetLanguage: "ms",
  storageKey: "karanganAI.full.v1",
  xp: {
    saveWord: 2,
    comprehension: 10,
    sentenceBuilder: 10,
    grammar: 10,
    recall: 10,
    writing: 20,
    missionReward: 30
  },
  imageFallbacks: {
    mentor: ["cikgu-aira.png","assets/images/cikgu-aira.png"],
    gotongRoyong: [
      "story-gotong-royong.png",
      "2411F84C-22BF-4BE2-848E-BE95A12D02A9.png",
      "assets/images/story-gotong-royong.png"
    ]
  }
};
