window.KAI_FLAGS = {
  aiFeedback: true,
  vocabularyBook: true,
  grammarHighlight: true,
  sentenceRecall: true,
  rewardSystem: true,
  profileStats: true,
  analyticsLocal: true,
  offlineFallback: true
};
