window.TextUtil = {
  esc(s=""){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));},
  normalizeWord(s=""){return s.toLowerCase().replace(/^[^a-zA-ZÀ-ÿ-]+|[^a-zA-ZÀ-ÿ-]+$/g,"");},
  sentenceFromTiles(arr){return arr.join(" ").replace(/\s+\./g,".");}
};
