window.DOM = {
  root(){return document.getElementById("app");},
  toast(msg){
    const t=document.getElementById("toast"); t.textContent=msg; t.classList.add("show");
    setTimeout(()=>t.classList.remove("show"),1600);
  },
  image(candidates=[],emoji="📚",className="media"){
    const first=candidates[0];
    if(!first) return `<div class="${className}">${emoji}</div>`;
    return `<div class="${className}"><img src="${first}" alt="" onerror="this.style.display='none';this.parentElement.insertAdjacentHTML('beforeend','<span>${emoji}</span>')"></div>`;
  }
};
