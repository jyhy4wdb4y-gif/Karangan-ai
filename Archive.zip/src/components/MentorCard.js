window.MentorCard = {
  text(){
    const s=window.KAI_STATE.state;
    const map={
      home:"Hai! Saya Cikgu Aira 👋 Hari ini kita belajar Bahasa Melayu bersama-sama!",
      story:"Baca perlahan-lahan. Tekan mana-mana perkataan untuk melihat maksudnya.",
      vocabulary:"Bagus! Simpan perkataan baharu supaya kita boleh ulang kaji nanti.",
      grammar:"Cari jenis perkataan yang betul. Kamu boleh buat!",
      writing:"Tulis dengan ayat kamu sendiri. Saya akan beri petunjuk untuk membantu kamu memperbaikinya.",
      reward:"Syabas! Setiap latihan membantu kamu menjadi penulis yang lebih yakin."
    };
    return map[s.route] || map.home;
  },
  render(){
    const s=window.KAI_STATE.state;
    if(!s.mentorOpen) return "";
    const img=window.KAI_CONFIG.imageFallbacks.mentor[0];
    const text=this.text();
    return `<aside class="mentor-card">
      <div class="mentor-avatar"><img src="${img}" alt="" onerror="this.parentElement.innerHTML='👩‍🏫'"></div>
      <div class="mentor-copy"><div class="eyebrow">CIKGU AIRA</div><p>${text}</p><button class="btn primary" data-speak="${window.TextUtil.esc(text)}">🎙️ Dengar</button></div>
      <button class="icon-btn" data-close-mentor aria-label="Tutup">×</button>
    </aside>`;
  }
};
