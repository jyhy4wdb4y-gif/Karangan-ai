window.AppShell = {
  navItem(route,label){const a=window.KAI_STATE.state.route===route?"active":"";return `<button class="nav-chip ${a}" data-route="${route}">${label}</button>`;},
  render(content){
    const s=window.KAI_STATE.state;
    return `<header class="topbar">
      <div class="brand"><div class="brand-logo">✨</div><div><h1>Karangan AI</h1><p>Belajar · Faham · Tulis</p></div></div>
      <button class="profile-btn" data-route="profile">🧒</button>
    </header>
    ${window.ProgressBar.render()}
    <nav class="main-nav">
      ${this.navItem("home","🏠 Utama")}
      ${this.navItem("mission","🎯 Misi")}
      ${this.navItem("story","📚 Cerita")}
      ${this.navItem("vocabulary","🗂️ Perkataan")}
      ${this.navItem("grammar","🎨 Tatabahasa")}
      ${this.navItem("writing","✍️ Karangan")}
      ${this.navItem("profile","🌟 Saya")}
    </nav>
    <main class="page">${content}</main>
    ${window.MentorCard.render()}
    <nav class="bottom-nav">
      <button data-route="home">🏠<span>Home</span></button>
      <button data-route="story">📚<span>Learn</span></button>
      <button data-route="writing">✍️<span>Create</span></button>
      <button data-route="profile">🌟<span>Me</span></button>
    </nav>`;
  }
};
