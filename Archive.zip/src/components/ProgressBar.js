window.ProgressBar = {
  percent(){
    const s=window.KAI_STATE.state;
    const done=Object.values(s.completed||{}).filter(Boolean).length;
    return Math.min(100,20 + done*8 + Math.floor(s.xp/50)*3);
  },
  render(){
    const p=this.percent();
    return `<div class="progress-wrap"><div class="progress-row"><span>Kemajuan Pembelajaran</span><strong>${p}%</strong></div><div class="progress"><div style="width:${p}%"></div></div></div>`;
  }
};
