window.KAI_STORIES = [
  {
    id: "gotong-royong",
    year: 3,
    title: "Gotong-royong di Taman",
    subtitle: "Amir dan keluarganya membersihkan taman rekreasi.",
    imageCandidates: window.KAI_CONFIG.imageFallbacks.gotongRoyong,
    emoji: "🌳🧹🍂",
    paragraphs: [
      "Pada hari Ahad yang cerah, Amir dan keluarganya pergi ke taman rekreasi untuk menyertai aktiviti gotong-royong.",
      "Amir mengutip sampah manakala ayahnya menyapu daun-daun kering di tepi laluan.",
      "Ibu Amir menanam beberapa pokok bunga yang cantik bersama penduduk taman.",
      "Selepas bekerja, kawasan taman menjadi bersih, kemas dan selesa.",
      "Amir berasa gembira kerana dapat bekerjasama dengan keluarganya dan menjaga kebersihan alam sekitar."
    ],
    vocab: {
      "cerah":"晴朗","menyertai":"参加","gotong-royong":"集体大扫除","mengutip":"捡拾",
      "sampah":"垃圾","menyapu":"扫","kering":"干的","menanam":"种植","beberapa":"一些",
      "cantik":"美丽","bersih":"干净","kemas":"整齐","selesa":"舒适","gembira":"开心",
      "bekerjasama":"合作","kebersihan":"清洁"
    },
    grammar: {
      verbs:["pergi","menyertai","mengutip","menyapu","menanam","bekerja","menjadi","bekerjasama","menjaga"],
      adjectives:["cerah","kering","cantik","bersih","kemas","selesa","gembira"],
      numbers:["beberapa"]
    },
    comprehension: [
      {q:"Bilakah Amir pergi ke taman?", options:["Hari Ahad","Hari Isnin","Hari Jumaat"], answer:0},
      {q:"Apakah yang dilakukan Amir?", options:["Mengutip sampah","Bermain bola","Tidur"], answer:0},
      {q:"Bagaimanakah keadaan taman selepas gotong-royong?", options:["Bersih dan kemas","Kotor","Gelap"], answer:0}
    ],
    builder: {
      words:["Amir","mengutip","sampah","di","taman","."],
      answer:"Amir mengutip sampah di taman."
    },
    recall: {
      sentence:"Amir _____ sampah di taman.",
      answer:"mengutip"
    },
    writingPrompt:"Tulis 4 hingga 6 ayat tentang aktiviti gotong-royong di taman. Ceritakan siapa, apa yang dilakukan dan perasaan kamu."
  },
  {
    id:"pantai",
    year:3,
    title:"Berkelah di Pantai",
    subtitle:"Aina dan keluarganya menikmati hari yang menyeronokkan di pantai.",
    imageCandidates:["story-pantai.png","assets/images/story-pantai.png"],
    emoji:"🏖️🌊☀️",
    paragraphs:[
      "Pada cuti sekolah, Aina dan keluarganya berkelah di pantai.",
      "Mereka membawa tikar, makanan dan minuman yang mencukupi.",
      "Aina bermain pasir bersama adiknya sebelum berenang di kawasan yang selamat.",
      "Ayah menyediakan makanan manakala ibu menyusun buah-buahan di atas tikar.",
      "Mereka pulang pada waktu petang dengan hati yang gembira."
    ],
    vocab:{"cuti":"假期","berkelah":"野餐","pantai":"海滩","tikar":"席子","mencukupi":"足够","pasir":"沙","berenang":"游泳","selamat":"安全","petang":"傍晚","gembira":"开心"},
    grammar:{verbs:["berkelah","membawa","bermain","berenang","menyediakan","menyusun","pulang"],adjectives:["mencukupi","selamat","gembira"],numbers:[]},
    comprehension:[
      {q:"Di manakah Aina berkelah?",options:["Pantai","Sekolah","Pasar"],answer:0},
      {q:"Apakah yang dimainkan Aina?",options:["Pasir","Komputer","Gitar"],answer:0}
    ],
    builder:{words:["Aina","bermain","pasir","di","pantai","."],answer:"Aina bermain pasir di pantai."},
    recall:{sentence:"Aina _____ pasir di pantai.",answer:"bermain"},
    writingPrompt:"Tulis 4 hingga 6 ayat tentang pengalaman berkelah di pantai."
  }
];
