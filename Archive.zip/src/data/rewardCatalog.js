window.KAI_REWARDS = {
  badges: [
    {id:"first-story",name:"Pembaca Pertama",icon:"📖"},
    {id:"word-hunter",name:"Pemburu Perkataan",icon:"🔎"},
    {id:"grammar-star",name:"Bintang Tatabahasa",icon:"⭐"},
    {id:"young-writer",name:"Penulis Muda",icon:"✍️"}
  ],
  levels: [
    {level:1,minXP:0,title:"Pemula"},
    {level:2,minXP:50,title:"Peneroka"},
    {level:3,minXP:120,title:"Penulis Hebat"},
    {level:4,minXP:220,title:"Juara Bahasa"}
  ]
};
