window.KAI_GRAMMAR_BANK = [
  {word:"menyapu", type:"Kata Kerja"},
  {word:"cantik", type:"Kata Adjektif"},
  {word:"beberapa", type:"Kata Bilangan"},
  {word:"mengutip", type:"Kata Kerja"},
  {word:"gembira", type:"Kata Adjektif"},
  {word:"bersih", type:"Kata Adjektif"}
];
