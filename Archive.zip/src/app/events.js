window.AppEvents = {
  bind(){
    document.addEventListener("click",async e=>{
      const st=window.KAI_STATE.state;
      const route=e.target.closest("[data-route]");
      if(route){ window.KAI_STATE.mutate(s=>{s.route=route.dataset.route;if(!["story","vocabulary","profile","home","mission"].includes(s.route)){ }},false); window.Router.render(); return; }

      if(e.target.closest("[data-close-mentor]")){window.KAI_STATE.mutate(s=>s.mentorOpen=false);return;}
      const sp=e.target.closest("[data-speak]"); if(sp){window.SpeechService.speak(sp.dataset.speak);return;}

      const open=e.target.closest("[data-open-story]");
      if(open){window.KAI_STATE.mutate(s=>{s.currentStoryId=open.dataset.openStory;s.storyStep="reader";s.route="story";s.selectedWord=null;});window.AnalyticsService.log("story_start",{storyId:open.dataset.openStory});return;}

      const word=e.target.closest("[data-word]");
      if(word){window.KAI_STATE.mutate(s=>s.selectedWord=word.dataset.word);return;}

      const save=e.target.closest("[data-save-word]");
      if(save){
        const story=window.Router.currentStory(), w=save.dataset.saveWord;
        if(!st.savedWords.some(x=>x.word===w)){window.KAI_STATE.mutate(s=>{s.savedWords.push({word:w,meaning:story.vocab[w]||"—",storyId:story.id});s.xp+=window.KAI_CONFIG.xp.saveWord;},false);window.DOM.toast("Perkataan disimpan +2 XP");window.Router.render();}
        else window.DOM.toast("Perkataan ini sudah disimpan.");
        return;
      }

      const gt=e.target.closest("[data-grammar-toggle]");
      if(gt){const key=gt.dataset.grammarToggle;window.KAI_STATE.mutate(s=>s.grammarMode[key]=!s.grammarMode[key]);return;}

      if(e.target.closest("[data-start-quiz]")){
        // lightweight comprehension handled before builder
        const story=window.Router.currentStory();
        const q=story.comprehension[0];
        const answer=prompt(q.q+"\n1. "+q.options[0]+"\n2. "+q.options[1]+"\n3. "+(q.options[2]||""));
        const ok=Number(answer)-1===q.answer;
        window.DOM.toast(ok?"Betul! 🌟":"Tidak mengapa. Kita terus berlatih.");
        window.KAI_STATE.mutate(s=>{s.completed.comprehension=true;s.xp+=window.KAI_CONFIG.xp.comprehension;s.storyStep="builder";s.builder=[];});
        return;
      }

      const add=e.target.closest("[data-add-built]"); if(add){window.KAI_STATE.mutate(s=>s.builder.push(Number(add.dataset.addBuilt)));return;}
      const rem=e.target.closest("[data-remove-built]"); if(rem){window.KAI_STATE.mutate(s=>s.builder.splice(Number(rem.dataset.removeBuilt),1));return;}
      if(e.target.closest("[data-reset-builder]")){window.KAI_STATE.mutate(s=>s.builder=[]);return;}
      if(e.target.closest("[data-check-builder]")){
        const story=window.Router.currentStory();
        const built=window.TextUtil.sentenceFromTiles(st.builder.map(i=>story.builder.words[i]));
        if(built===story.builder.answer){window.DOM.toast("Ayat betul! +10 XP");window.KAI_STATE.mutate(s=>{s.completed.builder=true;s.xp+=window.KAI_CONFIG.xp.sentenceBuilder;s.storyStep="grammar";s.grammar={index:0,score:0};});}
        else window.DOM.toast("Belum tepat. Cuba susun semula.");
        return;
      }

      const ga=e.target.closest("[data-grammar-answer]");
      if(ga){
        const item=window.KAI_GRAMMAR_BANK[st.grammar.index];
        if(ga.dataset.grammarAnswer===item.type) window.DOM.toast("Betul! 🎉"); else window.DOM.toast("Jawapan: "+item.type);
        window.KAI_STATE.mutate(s=>{if(ga.dataset.grammarAnswer===item.type)s.grammar.score++;s.grammar.index++;});
        return;
      }

      const cr=e.target.closest("[data-check-recall]");
      if(cr){
        const val=window.TextUtil.normalizeWord(document.getElementById("recallInput").value||"");
        if(val===cr.dataset.checkRecall.toLowerCase()){window.DOM.toast("Hebat! +10 XP");window.KAI_STATE.mutate(s=>{s.completed.recall=true;s.xp+=window.KAI_CONFIG.xp.recall;s.storyStep="writing";s.route="writing";});}
        else window.DOM.toast("Belum tepat. Cuba sekali lagi.");
        return;
      }

      if(e.target.closest("[data-save-writing]")){
        window.KAI_STATE.mutate(s=>s.writing=document.getElementById("writingInput").value||"",false);window.DOM.toast("Karangan disimpan.");return;
      }

      if(e.target.closest("[data-ai-feedback]")){
        const ta=document.getElementById("writingInput"), text=ta.value||"";
        if(text.trim().split(/\s+/).length<8){window.DOM.toast("Tulis beberapa ayat dahulu.");return;}
        window.KAI_STATE.mutate(s=>s.writing=text,false);
        const result=await window.AIService.feedback({text,prompt:window.Router.currentStory().writingPrompt});
        window.KAI_STATE.mutate(s=>{s.feedback=result;s.completed.writing=true;s.xp+=window.KAI_CONFIG.xp.writing;});
        return;
      }

      if(e.target.closest("[data-finish-mission]")){
        window.KAI_STATE.mutate(s=>{if(!s.completed.missionReward){s.xp+=window.KAI_CONFIG.xp.missionReward;s.completed.missionReward=true;}s.route="reward";s.storyStep="done";});
        return;
      }

      if(e.target.closest("[data-reset-progress]")){
        window.StorageService.reset();window.KAI_STATE.init();window.Router.render();window.DOM.toast("Progress telah direset.");return;
      }
    });
  }
};
