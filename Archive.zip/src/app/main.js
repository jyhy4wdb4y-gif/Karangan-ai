window.KAI_STATE.init();
window.AppEvents.bind();
window.Router.render();
