window.Router = {
  currentStory(){
    const id=window.KAI_STATE.state.currentStoryId;
    return window.KAI_STORIES.find(x=>x.id===id) || window.KAI_STORIES[0];
  },
  render(){
    const s=window.KAI_STATE.state, root=window.DOM.root();
    let html="";
    if(s.storyStep==="reader" && s.currentStoryId) html=window.StoryReaderPage.render(this.currentStory());
    else if(s.storyStep==="builder" && s.currentStoryId) html=window.SentenceBuilderPage.render(this.currentStory());
    else if(s.storyStep==="grammar" && s.currentStoryId) html=window.GrammarRainPage.render();
    else if(s.storyStep==="recall" && s.currentStoryId) html=window.SentenceRecallPage.render(this.currentStory());
    else if(s.storyStep==="writing" && s.currentStoryId) html=window.WritingStudioPage.render(this.currentStory());
    else{
      const routes={
        home:window.HomePage,
        mission:window.MissionPage,
        story:window.StoryLibraryPage,
        vocabulary:window.VocabularyPage,
        grammar:{render:()=>window.AppShell.render(`<section class="panel"><h2>🎨 Tatabahasa</h2><p class="muted">Pilih cerita dahulu supaya latihan grammar menggunakan konteks pembelajaran yang sama.</p><button class="btn primary" data-route="story">Pilih Cerita</button></section>`)},
        writing:{render:()=>window.AppShell.render(`<section class="panel"><h2>✍️ Creative Studio</h2><p class="muted">Mulakan melalui cerita supaya tugasan menulis berkait dengan bahan pembelajaran.</p><button class="btn primary" data-route="story">Pilih Cerita</button></section>`)},
        reward:window.RewardPage,
        profile:window.ProfilePage
      };
      html=(routes[s.route]||window.HomePage).render();
    }
    root.innerHTML=html;
    const auto=root.querySelector("[data-auto-next='recall']");
    if(auto){
      window.KAI_STATE.mutate(st=>{st.storyStep="recall";st.completed.grammar=true;st.xp+=window.KAI_CONFIG.xp.grammar;},false);
      setTimeout(()=>this.render(),0);
    }
  }
};
