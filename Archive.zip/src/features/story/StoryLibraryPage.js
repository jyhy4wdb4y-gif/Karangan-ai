window.StoryLibraryPage = {
  render(){
    const cards=window.KAI_STORIES.map(st=>`<article class="story-card">
      ${window.DOM.image(st.imageCandidates,st.emoji,"story-image")}
      <div class="story-body"><span class="pill">Tahun ${st.year}</span><h3>${st.title}</h3><p>${st.subtitle}</p><button class="btn primary" data-open-story="${st.id}">Mulakan Cerita</button></div>
    </article>`).join("");
    return window.AppShell.render(`<section class="hero-card"><h2>📚 Pilih Cerita</h2><p>Pilih satu cerita untuk memulakan pembelajaran.</p></section><section class="story-grid">${cards}</section>`);
  }
};
