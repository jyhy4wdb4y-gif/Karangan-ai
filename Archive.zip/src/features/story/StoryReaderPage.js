window.StoryReaderPage = {
  token(story,text){
    const s=window.KAI_STATE.state;
    return text.split(/(\s+)/).map(t=>{
      if(/^\s+$/.test(t))return t;
      const n=window.TextUtil.normalizeWord(t);
      const cls=["word"];
      if(s.grammarMode.verbs && story.grammar.verbs.includes(n))cls.push("verb");
      if(s.grammarMode.adjectives && story.grammar.adjectives.includes(n))cls.push("adj");
      if(s.grammarMode.numbers && story.grammar.numbers.includes(n))cls.push("num");
      return `<span class="${cls.join(" ")}" data-word="${n}">${window.TextUtil.esc(t)}</span>`;
    }).join("");
  },
  render(story){
    const s=window.KAI_STATE.state;
    const sel=s.selectedWord;
    const meaning=sel ? (story.vocab[sel]||"暂无词义") : "";
    return window.AppShell.render(`<div class="two-col">
      <section class="panel">
        ${window.DOM.image(story.imageCandidates,story.emoji,"reader-image")}
        <span class="pill">Tahun ${story.year}</span><h2>${story.title}</h2>
        <p class="muted">Tekan mana-mana perkataan untuk melihat maksud 中文.</p>
        <div class="legend-row">
          <button class="legend" data-grammar-toggle="verbs">🔵 Kata Kerja</button>
          <button class="legend" data-grammar-toggle="adjectives">🟡 Kata Adjektif</button>
          <button class="legend" data-grammar-toggle="numbers">🟢 Kata Bilangan</button>
        </div>
        <div class="story-text">${story.paragraphs.map(p=>`<p>${this.token(story,p)}</p>`).join("")}</div>
        <div class="actions"><button class="btn primary" data-speak="${window.TextUtil.esc(story.paragraphs.join(" "))}">🔊 Dengar Cerita</button><button class="btn success" data-start-quiz>Seterusnya → Kefahaman</button></div>
      </section>
      <aside class="panel sticky">
        <h3>🔎 Maksud Perkataan</h3>
        ${sel?`<div class="translation-word">${sel}</div><div class="translation-cn">${meaning}</div><div class="actions"><button class="btn primary" data-save-word="${sel}">＋ Simpan Word</button><button class="btn soft" data-speak="${sel}">🔊 Sebut</button></div>`:`<div class="empty">Tekan satu perkataan dalam cerita.</div>`}
      </aside>
    </div>`);
  }
};
