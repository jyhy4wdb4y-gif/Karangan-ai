window.SentenceBuilderPage = {
  render(story){
    const s=window.KAI_STATE.state;
    const built=s.builder.map(i=>story.builder.words[i]);
    const remaining=story.builder.words.map((w,i)=>({w,i})).filter(x=>!s.builder.includes(x.i));
    return window.AppShell.render(`<section class="panel"><span class="pill">Sentence Builder</span><h2>Bina ayat yang betul</h2>
      <div class="builder-zone">${built.length?built.map((w,j)=>`<button class="tile" data-remove-built="${j}">${w}</button>`).join(""):`<span class="muted">Ayat kamu akan muncul di sini.</span>`}</div>
      <div class="tile-bank">${remaining.map(x=>`<button class="tile" data-add-built="${x.i}">${x.w}</button>`).join("")}</div>
      <div class="actions"><button class="btn primary" data-check-builder>Semak Ayat</button><button class="btn soft" data-reset-builder>Ulang</button></div>
    </section>`);
  }
};
