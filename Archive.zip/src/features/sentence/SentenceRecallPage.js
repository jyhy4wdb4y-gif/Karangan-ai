window.SentenceRecallPage = {
  render(story){
    return window.AppShell.render(`<section class="panel"><span class="pill">Sentence Recall</span><h2>Ingat semula perkataan</h2>
      <p class="question">${story.recall.sentence}</p><input id="recallInput" class="text-input" placeholder="Taip perkataan yang hilang">
      <div class="actions"><button class="btn primary" data-check-recall="${story.recall.answer}">Semak</button></div>
    </section>`);
  }
};
