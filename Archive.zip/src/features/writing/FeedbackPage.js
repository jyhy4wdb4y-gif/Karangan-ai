window.FeedbackPage = {
  renderInline(data){
    const f=data.feedback||{};
    return `<section class="panel feedback-panel"><span class="pill">AI Feedback · ${data.source==="local"?"Offline fallback":"AI"}</span>
      <div class="score">${data.score||0}</div><p class="muted">Skor latihan /100 — untuk pembelajaran, bukan peperiksaan rasmi.</p>
      <div class="feedback-grid">
        <div class="feedback-card"><strong>🌟 Pujian</strong><p>${window.TextUtil.esc(f.pujian||"Bagus!")}</p></div>
        <div class="feedback-card"><strong>💡 Apa yang baik</strong><p>${window.TextUtil.esc((f.baik||[]).join(" ")||"Teruskan usaha.")}</p></div>
        <div class="feedback-card"><strong>🔧 Cuba Baiki</strong><p>${window.TextUtil.esc((f.baiki||[]).join(" "))}</p></div>
        <div class="feedback-card"><strong>❓ Soalan Cikgu Aira</strong><p>${window.TextUtil.esc(f.soalan||"Apa lagi yang boleh kamu tambah?")}</p></div>
      </div>
      <div class="actions"><button class="btn success" data-finish-mission>Siap & Ambil Ganjaran 🎁</button></div>
    </section>`;
  }
};
