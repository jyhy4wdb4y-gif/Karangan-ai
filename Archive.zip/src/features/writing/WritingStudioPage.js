window.WritingStudioPage = {
  render(story){
    const s=window.KAI_STATE.state;
    return window.AppShell.render(`<section class="panel"><span class="pill">Creative Studio</span><h2>✍️ Tulis Karangan Kamu</h2>
      <p class="muted">${story.writingPrompt}</p><textarea id="writingInput" class="writing-area" placeholder="Mula menulis di sini...">${window.TextUtil.esc(s.writing||"")}</textarea>
      <div class="actions"><button class="btn primary" data-ai-feedback>✨ Semak dengan Cikgu Aira</button><button class="btn soft" data-save-writing>Simpan</button></div>
    </section>${s.feedback?window.FeedbackPage.renderInline(s.feedback):""}`);
  }
};
