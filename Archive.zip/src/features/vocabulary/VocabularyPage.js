window.VocabularyPage = {
  render(){
    const words=window.KAI_STATE.state.savedWords;
    return window.AppShell.render(`<section class="hero-card"><h2>🗂️ Vocabulary Book</h2><p>Perkataan yang disimpan akan kekal pada peranti ini.</p></section>
      <section class="panel"><div class="chip-grid">${words.length?words.map(w=>`<div class="word-chip"><strong>${w.word}</strong><span>${w.meaning}</span><button data-speak="${w.word}">🔊</button></div>`).join(""):`<div class="empty">Belum ada perkataan. Baca cerita dan simpan perkataan baharu.</div>`}</div></section>`);
  }
};
