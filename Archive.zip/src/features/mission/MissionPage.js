window.MissionPage = {
  render(){
    return window.AppShell.render(`<section class="panel">
      <span class="pill">Today's Mission</span><h2>🎯 Misi Bahasa Melayu</h2>
      <div class="timeline">
        ${["1. Baca Cerita","2. Faham Perkataan","3. Bina Ayat","4. Grammar Rain","5. Ingat Semula","6. Tulis Karangan","7. Baiki dengan Cikgu Aira","8. Ambil Ganjaran"].map(x=>`<div class="timeline-item">${x}</div>`).join("")}
      </div>
      <div class="actions"><button class="btn primary" data-route="story">Mula dengan Cerita</button></div>
    </section>`);
  }
};
