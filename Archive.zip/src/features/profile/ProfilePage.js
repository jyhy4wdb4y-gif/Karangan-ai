window.ProfilePage = {
  getLevel(xp){
    const lv=[...window.KAI_REWARDS.levels].reverse().find(x=>xp>=x.minXP);
    return lv||window.KAI_REWARDS.levels[0];
  },
  render(){
    const s=window.KAI_STATE.state, lv=this.getLevel(s.xp);
    return window.AppShell.render(`<div class="two-col"><section class="panel center">
      ${window.DOM.image(window.KAI_CONFIG.imageFallbacks.mentor,"👩‍🏫","avatar-large")}
      <h2>Level ${lv.level} · ${lv.title}</h2><div class="score">${s.xp} XP</div><p class="muted">Terus belajar untuk membuka tahap baharu.</p>
    </section><section class="panel"><h2>📊 Profil Pembelajaran</h2>
      <div class="stats-grid"><div class="stat-card">Perkataan<strong>${s.savedWords.length}</strong></div><div class="stat-card">Badges<strong>${s.badges.length}</strong></div><div class="stat-card">XP<strong>${s.xp}</strong></div></div>
      <div class="actions"><button class="btn danger" data-reset-progress>Reset Demo Progress</button></div>
    </section></div>`);
  }
};
