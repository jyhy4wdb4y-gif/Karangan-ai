window.GrammarRainPage = {
  render(){
    const s=window.KAI_STATE.state;
    const item=window.KAI_GRAMMAR_BANK[s.grammar.index];
    if(!item){ return `<div data-auto-next="recall"></div>`; }
    return window.AppShell.render(`<section class="panel"><span class="pill">Grammar Rain ${s.grammar.index+1}/${window.KAI_GRAMMAR_BANK.length}</span>
      <h2>🎨 Pilih kategori yang betul</h2>
      <div class="grammar-zone"><div class="grammar-word">${item.word}</div><p>Apakah jenis perkataan ini?</p>
        <div class="actions center"><button class="btn soft" data-grammar-answer="Kata Kerja">Kata Kerja</button><button class="btn soft" data-grammar-answer="Kata Adjektif">Kata Adjektif</button><button class="btn soft" data-grammar-answer="Kata Bilangan">Kata Bilangan</button></div>
      </div>
    </section>`);
  }
};
