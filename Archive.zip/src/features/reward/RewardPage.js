window.RewardPage = {
  render(){
    const s=window.KAI_STATE.state;
    return window.AppShell.render(`<section class="panel reward-panel"><div class="reward-emoji">🎁</div><h2>Syabas!</h2>
      <p>Kamu telah melengkapkan satu learning loop.</p><div class="score">+${window.KAI_CONFIG.xp.missionReward} XP</div>
      <div class="actions"><button class="btn primary" data-route="profile">Lihat Perkembangan Avatar</button><button class="btn soft" data-route="story">Belajar Cerita Lain</button></div>
    </section>`);
  }
};
