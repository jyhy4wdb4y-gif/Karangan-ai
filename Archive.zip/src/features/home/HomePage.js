window.HomePage = {
  render(){
    const s=window.KAI_STATE.state;
    const done=Object.values(s.completed||{}).filter(Boolean).length;
    return window.AppShell.render(`
      <section class="hero-card">
        <span class="pill">Misi Hari Ini</span>
        <h2>Jom jadi penulis hebat! 🌟</h2>
        <p>Ikut satu perjalanan lengkap: baca → faham → berlatih → ingat → tulis → baiki → ganjaran.</p>
        <div class="actions"><button class="btn primary" data-route="mission">Mulakan Misi</button><button class="btn soft" data-route="vocabulary">Vocabulary Book</button></div>
      </section>
      <section class="stats-grid">
        <div class="stat-card">⭐ XP<strong>${s.xp}</strong></div>
        <div class="stat-card">🗂️ Perkataan<strong>${s.savedWords.length}</strong></div>
        <div class="stat-card">✅ Aktiviti<strong>${done}</strong></div>
      </section>
      <section class="panel">
        <h3>Core Learning Loop</h3>
        <p class="muted">Story → Vocabulary → Sentence Builder → Grammar Rain → Sentence Recall → Creative Studio → AI Feedback → Improve → Reward → Avatar Growth.</p>
      </section>`);
  }
};
