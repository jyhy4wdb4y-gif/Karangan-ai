window.StorageService = {
  load(){
    try { return JSON.parse(localStorage.getItem(window.KAI_CONFIG.storageKey) || "null"); }
    catch(e){ return null; }
  },
  save(state){
    try { localStorage.setItem(window.KAI_CONFIG.storageKey, JSON.stringify(state)); }
    catch(e){ console.warn("Storage unavailable",e); }
  },
  reset(){ localStorage.removeItem(window.KAI_CONFIG.storageKey); }
};
