window.AIService = {
  async feedback({text,prompt}){
    const controller = new AbortController();
    const timeout = setTimeout(()=>controller.abort(),15000);
    try{
      const r = await fetch("/api/feedback",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({text,prompt,year:window.KAI_CONFIG.targetYear,mentorLanguage:window.KAI_CONFIG.mentorLanguage}),
        signal:controller.signal
      });
      if(!r.ok) throw new Error("AI unavailable");
      return await r.json();
    }catch(e){
      return this.localFallback(text);
    }finally{ clearTimeout(timeout); }
  },
  localFallback(text){
    const t=text.trim();
    const words=t.split(/\s+/).filter(Boolean);
    const sentences=t.split(/[.!?]+/).map(x=>x.trim()).filter(Boolean);
    let score=45;
    if(sentences.length>=4)score+=20;
    if(words.length>=25)score+=15;
    if(/\b(kerana|kemudian|selepas|manakala|tetapi)\b/i.test(t))score+=10;
    if(/[.!?]$/.test(t))score+=5;
    score=Math.min(95,score);
    return {
      source:"local",
      score,
      feedback:{
        pujian:"Bagus kerana kamu sudah menulis sendiri.",
        baik:sentences.length>=4?["Kamu sudah menulis beberapa ayat lengkap."]:[],
        baiki:[
          sentences.length<4?"Tambah ayat sehingga sekurang-kurangnya 4 ayat.":"Tambah butiran supaya cerita lebih jelas.",
          /\b(kerana|kemudian|selepas|manakala|tetapi)\b/i.test(t)?"Semak ejaan dan tanda baca.":"Cuba gunakan kata hubung seperti “kemudian” atau “kerana”."
        ],
        soalan:"Apakah satu lagi perkara yang boleh kamu tambah supaya cerita lebih jelas?"
      }
    };
  }
};
