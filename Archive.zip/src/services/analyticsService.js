window.AnalyticsService = {
  log(event,payload={}){
    if(!window.KAI_FLAGS.analyticsLocal) return;
    const key="karanganAI.events";
    const events=JSON.parse(localStorage.getItem(key)||"[]");
    events.push({event,payload,at:new Date().toISOString()});
    localStorage.setItem(key,JSON.stringify(events.slice(-200)));
  }
};
