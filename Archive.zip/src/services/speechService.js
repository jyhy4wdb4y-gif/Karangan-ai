window.SpeechService = {
  speak(text){
    if(!("speechSynthesis" in window)) return window.DOM.toast("Peranti ini belum menyokong suara.");
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "ms-MY";
    u.rate = 0.9;
    speechSynthesis.speak(u);
  }
};
